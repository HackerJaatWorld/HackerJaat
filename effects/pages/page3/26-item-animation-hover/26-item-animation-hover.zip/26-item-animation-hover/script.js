(function ($) {
  $(function () {

    

  });
})(jQuery);